#pragma warning disable 1587
/// \file
/// <summary>Outdated. Here to overwrite older files on import.</summary>
#pragma warning restore 1587

// This class got outdated. As updates from the Asset Store won't delete files, this is emptied.